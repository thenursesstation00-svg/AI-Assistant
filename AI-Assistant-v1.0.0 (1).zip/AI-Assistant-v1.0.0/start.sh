#!/bin/bash
# AI Assistant v1.0.0 - Self-Learning AI Editor
echo "🧠 AI Assistant v1.0.0 - Self-Learning AI Editor"
echo "================================================"
echo "Starting installation and setup..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required but not installed."
    echo "Please install Node.js 16+ from https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js found: $(node --version)"

# Install main dependencies
echo "📦 Installing main dependencies..."
npm install --production

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd backend
npm install --production
cd ..

echo "🚀 Setup complete! Starting AI Assistant..."
echo ""
echo "🎯 Features available:"
echo "  ✨ Self-Learning AI that improves from every action"
echo "  🧬 Meta-programming - AI can modify its own code"
echo "  🔗 External editor integration (GitHub, VS Code, etc.)"
echo "  📊 Real-time learning statistics"
echo "  🛡️ Safety-first design with automatic backups"
echo ""

# Start the application
npm start